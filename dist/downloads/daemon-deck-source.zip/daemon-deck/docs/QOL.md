**v1.18.2:** refined the chess icon to use centered, explicit line geometry. The four new icons use the same 24px grid, 1.6px stroke, rounded line ends and theme color as the shared collection. The Exchange single-currency fix is included.

## v1.18.1 — Routine/game icons and Exchange balance cleanup

Added four consistent 24px line icons: Inhaler, Syringe, Checkered board and Chess (king). All 266 shared icon choices work in the existing selectors, including Dungeon item customization. Existing saved icon IDs remain unchanged.

The Exchange balance retains its leading Eurodollar icon and now formats only the numeric amount beside it, removing the redundant second currency prefix. Header balances and ordinary prices still use their single currency prefix.

304 tests pass. Mobile checks confirm exactly one Eurodollar symbol in the balance banner, all four icon choices and persistent Inhaler selection. Android compilation and exact bundled-asset parity pass.

## v1.18.0 — Compact Dungeon shop and optional item icons

Dungeon consumables use compact adjacent cards (two columns on phones). Short effect summaries, prices, free-use counts and activation remain visible. The diamond button opens full rules and optional icon editing: existing icon library, custom symbol or uploaded PNG/JPEG/WebP/GIF. Save/clear changes explicitly; choices persist in backups. Assigned icons replace active consumable text on the player card with small accessible icons; unassigned buffs retain text. Stimpack has no ongoing buff to display.

Prices are Stimpack 9,000 €$, Buffout 7,000 €$, Jet 9,000 €$ and Med-X 11,000 €$. Free uses remain free. Overall loot chances stay Mid 35% / High 65%. Given a drop, Stimpack/Buffout/Jet each have 30% and Med-X 10%, identically across tiers. Thus Med-X drops on 3.5% of Mid wins or 6.5% of High wins. Nothing auto-activates on collection.

304 tests pass, covering prices, deterministic loot distribution, icon backup validation and existing combat/recovery behavior. Mobile browser checks verify adjacent 143px sample cards, icon selection/save/reload, active icon versus text fallback, removal and 140% text on 320/390px viewports. Android compilation and exact bundled web-asset parity pass. Physical-device testing remains pending.


## v1.17.0 — Grid Reboot fix, List typography and saved loot uses

Grid Reboot clears deployed devices and pending setup together with the replaced board. This fixes the reported Battery record surviving its tile and causing repeated validation/AI failures. Verified against the exact uploaded pre-failure state and covered by a Battery/Machine Gun regression test with subsequent AI action.

Appearance now has a separate **Mission List text size** slider (60–200%, default 100%), saved through the existing appearance Save flow and included in backups. It controls List typography independently of the global text-size slider; Tiles retain global typography.

The death counter is removed. Zero health is displayed/logged as **Downed**: restore health to continue. Only enemy timeout fails an encounter. Internal legacy status names and historical records remain compatible; no progress or old streak records are rewritten.

Mid/High drops now select only Stimpack, Buffout, Jet or Med-X, retaining the 35%/65% chances. Each successful drop banks **one free use**, carried between encounters and saved in backups. Drops never activate automatically and never consume user-made reward stock. Existing user reward inventories remain intact. Each Dungeon shop item shows its free-use count; **Use free** applies the item on demand, consuming one credit only after successful application and charging no Eurodollars. Once free uses are exhausted, its normal Buy & use price returns. Failed/duplicate uses consume neither inventory nor money. Ongoing buffs still cannot stack with themselves.

Validation: 301 tests, independent slider save/reload, free-use shop/count/activation/no-charge browser checks, removed-counter checks, Android compilation and bundled-asset parity. Physical-device testing remains pending.


## v1.15.0 — Operator terminal and encounter consumables

Deck is now a cyberpunk biometric terminal: name/designation, level, XP, balance, completed and overdue missions, health/Vitals, Attribute network and activity. Character creation is replaced by identity editing; existing character data remains in backups for compatibility. The body illustration has been removed entirely; Deck now uses a full-width identity header and a grid of stat panels.

Player Cloak reduces damage by 75% for its existing two enemy actions and keeps reflection. Exchange Dungeon Items are buy-and-use, requiring a current encounter:

| Item | Price (€$) | Effect |
|---|---:|---|
| Stimpack | 5,000 | Up to 700 HP, respecting missing health and recovery capacity |
| Buffout | 3,000 | Total combat recovery capacity becomes 2,400 HP; +10 per damaging player hit, before enemy defenses; no immediate healing |
| Jet | 5,000 | Double mana gains, including Batteries, respecting channel caps, mana locks and Field Patch's no-mana rule |
| Med-X | 5,000 | 50% incoming damage reduction; Cloak takes priority at 75%, without stacking |

Buffout, Jet and Med-X persist for the current enemy through death, saves and board recovery; they end when the encounter ends. Repeat purchases of an active buff are rejected without charge. Jet's unfinished duration wording was interpreted as the current encounter, consistent with the other items. Buffout sets a 2,400 total budget, rather than adding 2,400; used healing is preserved. Mission XP healing still bypasses recovery limits. Player maximum HP remains 1,400.

296 automated tests pass, including consumable costs, capacity, no stacking, mana gains, Med-X/Cloak priority, damage and save validation. Mobile browser checks cover the Deck, identity editor, shop and runtime errors. Android compilation and bundled-asset parity pass; physical-device testing remains pending.


## v1.14.0 — Alarm dismissal and Dungeon recovery

Ringing alarms expose an in-app Dismiss control and a permanent Config backup button. Combat replay validation no longer rejects otherwise valid encounter progress: invalid replay cache is dropped, with a narrow combat-history repair fallback. Config → Dungeon recovery refreshes a stuck grid and clears replay/audit data after confirmation, preserving HP, enemy HP, mana, currency, streak, healing budget and deadline. Recovery does not undo rewarded turns. Failed combat actions pause AI retry until recovery/resume.

Deaths no longer break streaks. New Low/Mid/High encounters expire after 2/4/6 days; existing encounters keep their deadline. Historical death-loss records remain historical. The consecutive High-tier Boss Streak still ends after a Low/Mid victory.

Exchange separates Dungeon Items and User-made Items. A Combat Stim costs 1,000 €$ and heals up to 300 HP, limited by missing HP and the shared 1,300-HP recovery budget; no charge when healing is unavailable. Mission healing still bypasses the budget.

Missions have a saved Tiles/List toggle. List hides tags visually and compacts layout while retaining icons, descriptions, dates, recurrence, step progress, rewards and controls. Filters apply to both views.

Validation: 291 tests; mobile browser checks for alarm bridge dismissal, saved list selection, shop sections and recovery controls; signed Android build. The exact reported save was unavailable, so the specific replay failure was not reproduced. Device alarm/full-screen behavior still needs physical-phone testing.


# QOL updates — v1.13.0

Branch: `QOL-Updates`; Android version code 39, signed with the existing development certificate.

## Icons and mission filters

The shared selector now includes 262 icons. The nine additions are Eurodollar (€$), Toothbrush, Tooth, Shower, Shirt, Pants, Hair brush, Medical/first aid and a simple Heart. They use the existing 24px line style, work on quests/Attributes/Skills and persist by stable IDs. Uploaded images and existing icons are preserved.

Mission sorting defaults to **Due date, earliest first**. The sort and Calendar controls are app-owned dropdowns rather than Android select dialogs. The adjacent arrow shows the current direction and reverses it. Switching sort fields starts with that field's natural order (earliest due, newest created, highest XP or A–Z). The independent Calendar filter offers **All / Calendar / Non-Calendar**, combining with the existing status, tag, Attribute and Skill filters. Actual adjusted/extended deadlines determine due sorting; undated repeatable side quests stay last.

Cold start and app resume restore Due date/default direction and Calendar=All. Temporary choices remain usable while navigating within a session. Resuming does not discard an open editor draft.

## Overdue notifications

Reminders & alarm audio contains an enabled-by-default overdue toggle and a 1–365 day interval, initially **2 days**. A dated active quest receives its first overdue notification at effective deadline + interval, then every interval until completion, failure, deletion, disabling the setting or its repeat cutoff. Old missed intervals are skipped rather than replayed as a notification flood.

These alerts always use **notification** delivery, even when the deadline is an Alarm. Mission-specific notification audio overrides the global notification sound as before. Repeating schedule metadata includes the chosen sound and delivery defaults. Infinite undated Repeatable side quests are excluded.

Android stores the event queue locally, schedules its earliest event and delivers an entire due batch in one wake-up. The receiver advances overdue events and calendar recurrence chains; it does not rely on an open WebView or JavaScript timer. Boot, clock/timezone changes and package replacement restore the queue. Plan replacement cancels pending broadcasts, and stale receipts must match a current event ID/timestamp before they can advance the queue. Completing/failing/deleting a quest or changing settings immediately replaces the native plan. Future cycle deadlines honor stored per-date overrides. Android channels, permissions, Do Not Disturb and manufacturer restrictions still apply.

Web notifications remain session-only under browser control. Desktop/mobile browser timing is not a substitute for background Android delivery.

## Scheduled recurrence, failure and extension

This applies to scheduled daily/weekly/biweekly/monthly/yearly recurrence. It does not add dates to unlimited **Repeatable** side quests.

For an occurrence with a next repeat, the latest deadline and automatic-failure point are **24 elapsed hours before that next scheduled deadline**. The point cannot precede the current occurrence's original deadline; this prevents failure before the deadline during a 23-hour daylight-saving day. A normal daily quest consequently fails exactly at its deadline. A weekly quest can remain overdue until six days after its original deadline. The final occurrence of a count/until rule has no next repeat and therefore no such automatic cutoff.

Manual failure before the current original deadline queues the successor until that cycle boundary. If failure happens after the successor's cycle has already begun, it becomes available immediately. Daily auto-failure at the deadline releases the next daily occurrence then, with the following day's deadline. Each series has one current occurrence; catch-up can archive missed occurrences and bring its current cycle forward after the app was closed. Failed records keep their failure timestamp and no completion XP, currency or healing is awarded. Completed quests retain their existing next-occurrence behavior.

The native scheduler advances future alerts while closed. Quest records are reconciled on startup/resume and periodically while open using the scheduled timestamps. Save/reload is idempotent. The failed Calendar record remains visible and future repeats are still projected. Earlier failed history cannot be reopened over a newer existing occurrence; deleting the current series occurrence stops surviving records from recreating it. Deleting older history alone does not stop the current series.

Extend due date, the mission editor and per-date Calendar edits reject deadlines beyond the repeat cutoff. The extension dialog shows the latest permissible date; when there is no extension room it disables submission with an explanation. Older future overrides past the boundary are safely capped during reconciliation rather than rejecting the whole backup. Original-deadline information and slots/notes remain available. A draft saved after its occurrence auto-fails preserves the failed status and successor, instead of reactivating the old occurrence.

## Calendar gestures

Horizontal swipes within Calendar navigate its current view instead of switching app tabs:

- Month grid: previous/next month, retaining the selected day where possible.
- Day view: previous/next day.
- Week hourly/day section: one day at a time, crossing into the preceding/following week at the boundary.
- Week strip/period section: one full week.
- Schedule view: previous/next month, matching its displayed period.

Vertical scrolling, input editing and dialogs keep their usual behavior. Short taps still select events and dates; a completed horizontal swipe suppresses its trailing tap. Main-tab and quest-editor swipe navigation remains available outside Calendar content.

## Verification

288 automated tests pass, including defaults/migration, notification modes/audio, interval boundaries and cancellation, cutoff/release/idempotence, finite recurrence, backup metadata, extension limits, Calendar projections, sort/filter behavior, icon availability and prior Dungeon/app behavior. A pure Java recurrence test is compiled and compared against web calculations across daily/weekly/biweekly/monthly/yearly, daylight-saving, month-end, leap-year and ending rules. Test execution therefore requires a JDK on PATH; CI configures Java 21 before running it.

Browser checks cover custom dropdowns and menu bounds, reversed sorting, Calendar filtering, return/reload defaults, icon selection/save, overdue settings, editor-draft preservation, day/week/month swipes and week-boundary crossing, vertical-scroll behavior, mobile widths, daily auto-failure/release without rewards, and saving a draft after its cutoff. Offline reload checks confirm the new filter, icon and settings modules remain available. Native-bridge simulation checks emitted repeat plans and immediate setting updates/cancellation. Android compilation/signature and exact bundled web-asset parity are checked for the downloadable APK. Physical-phone notifications, audio and Doze behavior remain pending hardware testing.
